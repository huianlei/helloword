package geym.zbase.ch11.calc;

public class Calc{
	public int calc() {
		long l = 102852793018089712L;
		int m = Integer.MAX_VALUE;
		int a = 500;
		int b = 200;
		int c = 50;
		return (a+b) / c;
	}
}
