package geym.zbase.ch9;

import javax.annotation.Resource;

@Resource
public class SimpleUser {
	/** 类型 **/
	public static final int TYPE = 1;
	

	private int id;
	private String name;
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) throws IllegalStateException{
		try {
			this.id = id;
		} catch (IllegalStateException e) {
			System.out.println(e.toString());
		}
	}
	
	public String getName() {
		return name;
	}
	
	@Deprecated
	public void setName(String name) {
		this.name = name;
	}
	
	class InnerUser{
		private int age;
		public InnerUser(int iage) {
			this.age = iage;
		}
		
		public int getAge() {
			return age;
		}
	}
	
	public static class Pack{
		private int[] data = new int[10];
	}
}
