package site.iapps.jvmpractice;

import java.util.List;

public class ClassFileView {

	public static void print(String str1,String str2) {
		String str = str1 + str2;
		System.out.println(str);
	}
	
	public static String append(String str1,String str2) {
		String str = str1 + str2;
		return str;
	}
	
	private int cal(int a,List<Integer> list,int b) {
		int c = a + b;
		int d = a * b;
		int r = d - c;
		list.add(r);
		return Const.OK;
	}
}
