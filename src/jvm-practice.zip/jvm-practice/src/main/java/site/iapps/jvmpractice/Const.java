package site.iapps.jvmpractice;

public class Const {

	public static final String CHARSET = "UTF-8";
	
	public static final int OK = 0;
}
