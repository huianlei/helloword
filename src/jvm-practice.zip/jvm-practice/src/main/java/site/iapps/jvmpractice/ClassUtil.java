package site.iapps.jvmpractice;

import java.io.File;
import java.io.FileInputStream;

public class ClassUtil {
	
	private static final char[] HEX_CHAR = {'0', '1', '2', '3', '4', '5', 
            '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
	
	public static void main(String[] args) {
		String path = "D:\\beiyan\\xyj\\jvm-practice\\target\\classes\\geym\\zbase\\ch11\\calc\\Calc.class";
		readFile(path);
	}
	
	public static void readFile(String path) {
		try {
			FileInputStream fis = new FileInputStream(new File(path));
			int avaliable = fis.available();
			byte[] bs = new byte[avaliable];
			fis.read(bs);
			String str = bytesToHexFun2(bs);
			StringBuilder sb = new StringBuilder();
			for(int i=0;i<str.length();i++) {
				sb.append(str.charAt(i));
				if(i> 0 && i%32 == 0) {
					System.out.println(sb.toString().toUpperCase());
					sb.setLength(0);
				}
			}
			System.out.println(sb.toString().toUpperCase());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static String bytesToHexFun2(byte[] bytes) {
        char[] buf = new char[bytes.length * 2];
        int index = 0;
        for(byte b : bytes) {
            buf[index++] = HEX_CHAR[b >>> 4 & 0xf];
            buf[index++] = HEX_CHAR[b & 0xf];
        }

        return new String(buf);
    }
}
